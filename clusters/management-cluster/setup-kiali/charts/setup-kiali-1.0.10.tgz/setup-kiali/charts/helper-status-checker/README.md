

# helper-status-checker

  [![Artifact Hub](https://img.shields.io/endpoint?url=https://artifacthub.io/badge/repository/openshift-bootstraps)](https://artifacthub.io/packages/search?repo=openshift-bootstraps)
  [![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
  [![Lint and Test Charts](https://github.com/tjungbauer/helm-charts/actions/workflows/lint_and_test_charts.yml/badge.svg)](https://github.com/tjungbauer/helm-charts/actions/workflows/lint_and_test_charts.yml)
  [![Release Charts](https://github.com/tjungbauer/helm-charts/actions/workflows/release.yml/badge.svg)](https://github.com/tjungbauer/helm-charts/actions/workflows/release.yml)

  ![Version: 4.0.21](https://img.shields.io/badge/Version-4.0.21-informational?style=flat-square)

 

  ## Description

  A helper Chart that creates a job to verify if the deployments of an operator are running. To do so it creates a service account with a role to read the status of the Deployments.

This chart is used the check the installation status of an Operator.
Whenever a new Operator gets installed, this Chart can be called to verify if the status of the Operator is ready.
This is useful when you want to install an Operator AND configure it in the same Helm Chart. Typically, Argo CD will fail in such case,
because it would try to configure the CRD that the Operator provides immediately after the Subscription object becomes ready. However,
the CRD is not available yet, since the Operator is still installing itself.

It is best used as a Subchart, for example, https://github.com/tjungbauer/helm-charts/tree/main/charts/rhacm-full-stack

helper-status-checker will create a Service Account (incl. a ClusterRole and a ClusterRoleBinding) and a Job that will try to check the status of the Operator. If the Operator is not available after some time (configurable with mx_retries), the Job will fail.

NOTE: This chart can also be used to automatically approve an InstallPlan

Shipped **`values.yaml`** is intentionally empty so this subchart renders nothing until the parent chart sets values.

The **parameter table below** and the **full documented example** (including `# --` comments and defaults) are taken from **`values-example.yaml`** in this chart directory—not from `values.yaml`. Use that file as the reference when configuring this chart as a subchart or for local testing (`helm template … -f values-example.yaml`). CI helm-docs reads the same file (see **`.helm-docs.yml`**).

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| tjungbauer | <dev@stdin.at> | <https://blog.stderr.at/> |

## Sources
Source:
* <https://github.com/tjungbauer/helm-charts>
* <https://charts.stderr.at/>
* <https://github.com/tjungbauer/openshift-clusterconfig-gitops>

Source code: https://github.com/tjungbauer/helm-charts/tree/main/charts/helper-status-checker

## Parameters

Values below reflect **`values-example.yaml`**. Install-time defaults in the packaged chart remain empty in **`values.yaml`**.

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| additionalAnnotations | object | {} | Additional annotations on all status-checker hook resources. |
| additionalLabels | object | {} | Additional labels on all status-checker hook resources. |
| approver | bool | false | Enable automatic approval of an InstallPlan. Useful if the installation must be approved manually and you want to initially deploy the Operator using GitOps. |
| checks | list | none | Optional Argo CD sync-options for all hook resources. syncOptions: Replace=true List of checks that shall be performed. |
| checks[0] | object | `{"maxretries":20,"namespace":{"name":"openshift-logging"},"operatorName":"name-of-operator","serviceAccount":{"name":"status-checker"},"sleeptimer":20,"subscriptionName":"name-of-subscription","syncwave":0}` | Name of operator to check. Use the value of the currentCSV (packagemanifest) but WITHOUT the version !! |
| checks[0].maxretries | int | 20 | Maximum number of retries before the checks will fail |
| checks[0].namespace | object | `{"name":"openshift-logging"}` | Namespace where the status-checker Job shall be scheduled. |
| checks[0].serviceAccount | object | inherits ttlSecondsAfterFinished from chart root | Optional override for Job cleanup TTL in seconds ttlSecondsAfterFinished: 600 |
| checks[0].serviceAccount.name | string | `"status-checker"` | Name of the Service Account. |
| checks[0].sleeptimer | int | 20 | If the Operator is not yet ready wait this amount of seconds. |
| checks[0].subscriptionName | string | `"name-of-subscription"` | OPTIONAL: Name of subscription that shall be approved. In some cases the name of the Subscription is different to the name of the operator. @default --operatorName |
| checks[0].syncwave | int | 0 | Syncwave for the status-check Job. 0 is the recommended value. |
| enabled | bool | false | Enable or disable the status-checker configuration |
| ttlSecondsAfterFinished | int | 600 | Seconds to retain finished status-checker Jobs before Kubernetes deletes them |

## Example

Minimal install example (see **`values-example.yaml`** for all keys, comments, and defaults):

```yaml
---
enabled: true
approver: true

checks:
  - operatorName: name-of-operator

    sleeptimer: 20
    maxretries: 20

    namespace:
      name: openshift-logging
    syncwave: 3

    serviceAccount:
      name: "status-checker"
```

## Installing the Chart

To install the chart with the release name `my-release`:

```console
helm install my-release tjungbauer/<chart-name>>
```

The command deploys the chart on the Kubernetes cluster in the default configuration.

## Uninstalling the Chart

To uninstall/delete the my-release deployment:

```console
helm delete my-release
```

The command removes all the Kubernetes components associated with the chart and deletes the release.

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
